import React from 'react'

const ContactPage = () => {
  return (
    <div>ContactPage</div>
  )
}

export default ContactPage