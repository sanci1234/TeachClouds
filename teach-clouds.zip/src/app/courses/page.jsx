import React from 'react'

const CoursesPage = () => {
  return (
    <div>CoursesPage</div>
  )
}

export default CoursesPage